#!/bin/bash

for i in $@
	do 
		`mkdir "ex$i"`
	done
