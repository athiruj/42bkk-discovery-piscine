#!/bin/bash
ls -l | cat -e
